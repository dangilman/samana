# the python scripts in this folder can be used to run the analysis presented in JWST Lensed Quasar DM Survey III and IV
# the code versions used for the analyses were: pyHalo version 1.43 commit 64ea7a2, samana commit d57329d, and lenstronomy version 1.13.2 commit 370d932

# syntax for each file is:
# python3 he0435.py $1 A B
# where $1 is a TASK_ID passed through a SLURM job array. You can use this to parallelize the computation. Each job will produce an output folder "job_$1" with image magnifications, model parameters, etc
# A is the number of realizations to create per task. So for example running on 1000 CPUs, with $1 running from 1 to 1000, and A=100, would produce 100 * 1000 =100,000 total realizations
# B is a number that triggers the reconstruction of imaging data. The number is the negative log-likelihood of the flux ratios that triggers the reconstruction 
