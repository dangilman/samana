import numpy as np

_nuclear_narrow_line_region = ['UNIFORM', 20, 80]
_warm_dust_region = ['UNIFORM', 1, 10]
source_priors = {}
source_priors['B1422'] = {'source_size_pc': _nuclear_narrow_line_region,
                            'shapelets_order': None,
                          'mask_images_reconstruction': False}
source_priors['H1113'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': None,
                          'mask_images_reconstruction': False}
source_priors['J2017'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': None,
                          'mask_images_reconstruction': False}
source_priors['H1413'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': None,
                          'mask_images_reconstruction': True}
source_priors['HE0435'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': 28,
                           'mask_images_reconstruction': False}
source_priors['J0248'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': 4,
                          'mask_images_reconstruction': True}
source_priors['J0259'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': 10,
                          'mask_images_reconstruction': False}
source_priors['J0405'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': 3,
                          'mask_images_reconstruction': False}
source_priors['J0607'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': 3,
                          'mask_images_reconstruction': True}
source_priors['J0608'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': None,
                          'mask_images_reconstruction': True}
source_priors['J0659'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': 1,
                          'mask_images_reconstruction': True}
source_priors['J0803'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': None,
                          'mask_images_reconstruction': True}
source_priors['J0924'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': 6,
                          'mask_images_reconstruction': True}
source_priors['J1042'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': 5,
                          'mask_images_reconstruction': False}
source_priors['J1131'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': 10,
                          'mask_images_reconstruction': False}
source_priors['J1251'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': 7,
                          'mask_images_reconstruction': False}
source_priors['J1537'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': 8,
                          'mask_images_reconstruction': False}
source_priors['J2017'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': None,
                          'mask_images_reconstruction': False}
source_priors['J2145'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': None,
                          'mask_images_reconstruction': True}
source_priors['J2205'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': None,
                          'mask_images_reconstruction': True}
source_priors['J2344'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': None,
                          'mask_images_reconstruction': True}
source_priors['M1134'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': None,
                          'mask_images_reconstruction': True}
source_priors['MG0414'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': None,
                           'mask_images_reconstruction': True}
source_priors['PG1115'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': None,
                           'mask_images_reconstruction': False}
source_priors['PSJ0147'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': None,
                            'mask_images_reconstruction': True}
source_priors['PSJ1606'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': 8,
                            'mask_images_reconstruction': False}
source_priors['RXJ0911'] = {'source_size_pc': _nuclear_narrow_line_region,
                            'shapelets_order': None,
                            'mask_images_reconstruction': False}
source_priors['RXJ1131'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': 34,
                            'mask_images_reconstruction': False}
source_priors['WFI2026'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': None,
                            'mask_images_reconstruction': False}
source_priors['WFI2033'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': 24,
                            'mask_images_reconstruction': False}
source_priors['WGD2038'] = {'source_size_pc': _warm_dust_region,
                            'shapelets_order': 16,
                            'mask_images_reconstruction': False}

