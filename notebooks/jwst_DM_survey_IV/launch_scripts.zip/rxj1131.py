import numpy as np
from samana.forward_model import forward_model
from samana.analysis_util import quick_setup, numerics_setup, default_rendering_area, satellite_galaxy_priors
import os
import sys

def run():
    ######################## LENS SELECTION ########################
    lens_ID = 'RXJ1131'
    data_class, model_class = quick_setup(lens_ID)
    data_class = data_class()
    rescale_grid_size, rescale_grid_res = numerics_setup(lens_ID)
    cone_opening_angle_arcsec = default_rendering_area(data_class=data_class,
                                                       model_class=model_class)
    import flux_ratio_measurements
    fluxes = flux_ratio_measurements.measurements[lens_ID]['measured_fluxes']
    keep_flux_ratio_index = flux_ratio_measurements.measurements[lens_ID]['keep_flux_ratio_index']
    data_class.magnifications = fluxes
    data_class.flux_uncertainty = None
    data_class.flux_ratio_covariance_matrix = flux_ratio_measurements.measurements[lens_ID][
        'flux_ratio_covariance_matrix']
    data_class.keep_flux_ratio_index = keep_flux_ratio_index
    ######################## DARK MATTER PARAMETER PRIOR DEFINITIONS ########################
    import realization_priors_wdm as realization_priors
    preset_model_name = realization_priors.preset_model_name
    kwargs_sample_realization = realization_priors.kwargs_sample_realization
    kwargs_globular_cluster = realization_priors.kwargs_globular_cluster
    kwargs_globular_cluster['center_x'] = data_class.x_image
    kwargs_globular_cluster['center_y'] = data_class.y_image
    kwargs_sample_realization['kwargs_globular_clusters'] = ['FIXED', kwargs_globular_cluster]
    kwargs_sample_realization['cone_opening_angle_arcsec'] = ['FIXED', cone_opening_angle_arcsec]
    kappa_scale_subhalos = realization_priors.kappa_scale_subhalos
    log10_bound_mass_cut = realization_priors.log10_bound_mass_cut
    filter_subhalo_kwargs = realization_priors.filter_subhalo_kwargs
    filter_subhalo_kwargs['x_coords'] = data_class.x_image
    filter_subhalo_kwargs['y_coords'] = data_class.y_image
    ######################## MACROMODEL PRIOR ########################
    kwargs_sample_macro_fixed = {
        'gamma': ['GAUSSIAN', 2.1, 0.1],
        'OPTICAL_MULTIPOLE_PRIOR_M1': [],
        'satellite_1_theta_E': ['GAUSSIAN', 0.3, 0.2],
        'satellite_1_x': ['GAUSSIAN', -0.328, 0.05],
        'satellite_1_y': ['GAUSSIAN', 0.700, 0.05],
        'q': ['TRUNC-HALF-GAUSS', 0.88, 0.2,0.63, 0.999]
    }
    ######################## BACKGROUND SOURCE PRIORS ########################
    import background_source_priors
    kwargs_sample_source = {'source_size_pc': background_source_priors.source_priors[lens_ID]['source_size_pc']}
    kwargs_model_class = {'shapelets_order': background_source_priors.source_priors[lens_ID]['shapelets_order']}
    ######################## SETUP OUTPUT DIRECTORIES ########################
    if os.getenv('HOME') == '/Users/danielgilman':
        test_mode = True
        verbose = True
        base_path = os.getcwd()
        n_particles = 10
        n_iterations = 5
        job_index = 1
        parallel = False
        num_threads = 1
        tolerance_source_reconstruction = 0.01
        n_keep = 10
    else:
        test_mode = False
        verbose = False
        base_path = os.getenv('SCRATCH')
        n_particles = 10
        n_iterations = 80
        job_index = int(sys.argv[1])
        parallel = False
        num_threads = 1
        tolerance_source_reconstruction = float(sys.argv[3])
        n_keep = int(sys.argv[2])
        if base_path == '/scratch/midway3':
            base_path = '/scratch/midway3/gilmanda'
    random_seed_init = None
    ############################## RUN SIMULATION ################################
    readout_steps = 2
    use_imaging_data = False
    split_image_data_reconstruction = True
    if tolerance_source_reconstruction == -1 and split_image_data_reconstruction:
        output_path = base_path + '/' + lens_ID + '_WDMimgdatanew/'
        tolerance_source_reconstruction = np.inf
        tolerance = np.inf
    else:
        output_path = base_path + '/' + lens_ID + '_WDMnew/'
        tolerance = np.inf
    fitting_sequence_kwargs = [
        ['PSO', {'sigma_scale': 1., 'n_particles': n_particles,
                 'n_iterations': n_iterations,
                 'threadCount': num_threads}]
    ]
    forward_model(output_path,
                  job_index,
                  n_keep,
                  data_class,
                  model_class,
                  preset_model_name,
                  kwargs_sample_realization,
                  kwargs_sample_source,
                  kwargs_sample_macro_fixed,
                  tolerance,
                  random_seed_init=random_seed_init,
                  readout_steps=readout_steps,
                  rescale_grid_resolution=rescale_grid_res,
                  rescale_grid_size=rescale_grid_size,
                  kwargs_model_class=kwargs_model_class,
                  verbose=verbose,
                  n_pso_particles=n_particles,
                  n_pso_iterations=n_iterations,
                  num_threads=num_threads,
                  test_mode=test_mode,
                  use_imaging_data=use_imaging_data,
                  parallelize=parallel,
                  kappa_scale_subhalos=kappa_scale_subhalos,
                  log10_bound_mass_cut=log10_bound_mass_cut,
                  split_image_data_reconstruction=split_image_data_reconstruction,
                  filter_subhalo_kwargs=filter_subhalo_kwargs,
                  scipy_minimize_method='COBYQA_import',
                  fr_logL_source_reconstruction=tolerance_source_reconstruction,
                  fitting_sequence_kwargs=fitting_sequence_kwargs)

if __name__ == '__main__':
    run()
