import numpy as np

measurements = {}

cov_mat_1422 = np.array([[0.00029254, 0.00010477],
       [0.00010477, 0.00011459]])
measurements['B1422'] = {'measured_fluxes': np.array([0.88, 1.0, 0.64, 0.05]),
                               'flux_ratio_covariance_matrix': cov_mat_1422,
                               'keep_flux_ratio_index': [0,1],
                         	'uncertainty_on_ratios': True}

measurements['H1113'] = {'measured_fluxes': np.array([1.0, 1.21, 0.51, 0.71]),
                               'flux_ratio_uncertainties': np.array([0.01, 0.01, 0.01]),
                               'keep_flux_ratio_index': [0,1,2],
                         'uncertainty_on_ratios': True}


cov_mat_1413 = np.array([[0.0011952852595586859, 3.781028056669821e-05, 1.8944574945847236e-06],
                                                        [3.781028056669821e-05, 0.0008649304946056081, 1.2990535999187269e-05],
                                                        [1.8944574945847236e-06, 1.2990535999187269e-05, 0.0002263224941441235]])
measurements['H1413'] = {'measured_fluxes': np.array([1.0, 1.152, 0.975, 0.485]),
                               'flux_ratio_covariance_matrix': cov_mat_1413,
                               'keep_flux_ratio_index': [0,1,2],
                         'uncertainty_on_ratios': True}


cov_mat_0435 = np.array([[0.0005161032050153507, 1.4092644323619424e-05, 1.5474966187747706e-05], [1.4092644323619424e-05, 0.00043293962174831426, 1.243753314694643e-05],
 [1.5474966187747706e-05, 1.243753314694643e-05, 0.00018241299265942914]])
measurements['HE0435'] = {'measured_fluxes': np.array([1.0, 1.009, 0.928, 0.585]),
                               'flux_ratio_covariance_matrix': cov_mat_0435,
                               'keep_flux_ratio_index': [0,1,2],
                          'uncertainty_on_ratios': True}


cov_mat_0248 = np.array([[0.0006471627146752732, 2.4516621960310318e-05, 			4.9419268019388024e-05], [2.4516621960310318e-05, 0.0008889461915094544, 6.0156918938813144e-05],
 [4.9419268019388024e-05, 6.0156918938813144e-05, 0.000637108013194908]])
measurements['J0248'] = {'measured_fluxes': np.array([1.0, 1.040, 1.308, 1.078]),
 			'flux_ratio_covariance_matrix': cov_mat_0248,
			'keep_flux_ratio_index': [0,1,2],
			'uncertainty_on_ratios': True
			}

cov_mat_0259 = np.array([[0.0006990051494135893, 3.900012689848725e-06, 7.104988247659262e-05],
                                                              [3.900012689848725e-06, 0.000669390586981477, 6.248200261970465e-05],
                                                              [7.104988247659262e-05, 6.248200261970465e-05, 0.001532684573494796]])
measurements['J0259'] = {'measured_fluxes': np.array([1.0, 1.022, 1.000, 1.469]) ,
                               'flux_ratio_covariance_matrix': cov_mat_0259,
                               'keep_flux_ratio_index': [0,1,2],
                         'uncertainty_on_ratios': True}

cov_mat_0405 = np.array([[3.07746597e-04, 8.63236716e-05, 6.00374468e-05],
 [8.63236716e-05, 5.95504131e-04, 8.40919248e-05],
 [6.00374468e-05, 8.40919248e-05, 6.86674077e-04]])
measurements['J0405'] = {'measured_fluxes': np.array([1.0, 0.691, 1.059, 1.263]) ,
                               'flux_ratio_covariance_matrix': cov_mat_0405,
                               'keep_flux_ratio_index': [0,1,2],
                         'uncertainty_on_ratios': True}


cov_mat_0607 = np.array([[0.012677443629154052, 0.009228237002492107, 0.001973500212668741],
                                                                  [0.009228237002492107, 0.08415805726284303, 0.005654547158136215],
                                                                  [0.001973500212668741, 0.005654547158136215, 0.006362401366645787]])
measurements['J0607'] = {'measured_fluxes': np.array([1.0, 1.484, 4.124, 1.076]) ,
                               'flux_ratio_covariance_matrix': cov_mat_0607,
                               'keep_flux_ratio_index': [0,1,2],
                         'uncertainty_on_ratios': True}


cov_mat_0608 = np.array([[0.00010557224880073126, -1.3585528690128262e-06, -3.368883979800256e-05],
                                                             [-1.3585528690128262e-06, 6.44055753864071e-05, 1.983189083044633e-06],
                                                             [-3.368883979800256e-05, 1.983189083044633e-06, 0.00020017424802660176]])
measurements['J0608'] = {'measured_fluxes': np.array([1.0, 0.395, 0.360, 0.457]) ,
                               'flux_ratio_covariance_matrix': cov_mat_0608,
                               'keep_flux_ratio_index': [0,1,2],
                         'uncertainty_on_ratios': True}


cov_mat_0659 = np.array([[0.0008050949578874211, 6.357748101227342e-05, 0.00010760598825941302],
                                                              [6.357748101227342e-05, 0.0005193767498898855, 0.000311364950817225],
                                                             [0.00010760598825941302, 0.000311364950817225, 0.005906681898968367]])
measurements['J0659'] = {'measured_fluxes': np.array([1.0, 0.946, 0.686, 2.498]) ,
                               'flux_ratio_covariance_matrix': cov_mat_0659,
                               'keep_flux_ratio_index': [0,1,2],
                         'uncertainty_on_ratios': True}


cov_mat_0803 = np.array([[0.0006038723630326562, 5.6318794948926615e-06, 1.2658195831857684e-05],
                                                              [5.6318794948926615e-06, 7.310360957612793e-05, 5.023477159216848e-06],
                                                             [1.2658195831857684e-05, 5.023477159216848e-06, 0.00031528671545100895]])
measurements['J0803'] = {'measured_fluxes': np.array([1.0, 0.819, 0.255, 0.559]) ,
                               'flux_ratio_covariance_matrix': cov_mat_0803,
                               'keep_flux_ratio_index': [0,1,2],
                         'uncertainty_on_ratios': True}

cov_mat_0924 = np.array([[0.00014299853631096913, 5.907777393339943e-06, 3.3447587289496713e-06],
                                                              [5.907777393339943e-06, 0.0001151936995888641, 9.668352970724853e-06],
                                                              [3.3447587289496713e-06, 9.668352970724853e-06, 9.709504502538887e-05]])
measurements['J0924'] = {'measured_fluxes': np.array([1.0, 0.417, 0.416, 0.131]) ,
                               'flux_ratio_covariance_matrix': cov_mat_0924,
                               'keep_flux_ratio_index': [0,1,2],
                         'uncertainty_on_ratios': True}

cov_mat_1042 = np.array([[0.0010893629582988935, 4.914355674007782e-05, 3.409009632738971e-05],
                                                             [4.914355674007782e-05, 5.6043870823305845e-05, 6.430063994233894e-06],
                                                            [3.409009632738971e-05, 6.430063994233894e-06, 2.4059192174364168e-05]])
measurements['J1042'] = {'measured_fluxes': np.array([1.0, 0.315, 0.115, 0.076]) ,
                               'flux_ratio_covariance_matrix': cov_mat_1042,
                               'keep_flux_ratio_index': [0,1,2],
                         'uncertainty_on_ratios': True}


cov_mat_gral1131 = np.array([[0.0017994885056921248, 3.117717349748357e-05, 9.296165227895446e-05],
                                                            [3.117717349748357e-05, 0.009061481788629516, 0.0003673406808941061],
                                                            [9.296165227895446e-05, 0.0003673406808941061, 0.006392463735487027]])
measurements['J1131'] = {'measured_fluxes': np.array([1.0, 1.520, 3.997, 3.998]),
                               'flux_ratio_covariance_matrix': cov_mat_gral1131,
                               'keep_flux_ratio_index': [0,1,2],
                         'uncertainty_on_ratios': True}

cov_mat_1251 = np.array([[0.0007692154887224751, 6.165643341606856e-05, 2.3261237644190808e-05],
                                                              [6.165643341606856e-05, 0.0003873152305430854, 3.938470084218449e-05],
                                                              [2.3261237644190808e-05, 3.938470084218449e-05, 0.00011888366590749963]])
measurements['J1251'] = {'measured_fluxes': np.array([1.0, 0.551, 0.437, 0.195]) ,
                               'flux_ratio_covariance_matrix': cov_mat_1251,
                               'keep_flux_ratio_index': [0,1,2],
                         'uncertainty_on_ratios': True}

cov_mat_1537 = np.array([[0.0005659524623378763, 3.8905733549186235e-06, 5.201869184166901e-05],
                                                              [3.8905733549186235e-06, 0.000890567066935679, 5.6469678985492225e-05],
                                                              [5.201869184166901e-05, 5.6469678985492225e-05, 0.0004812789507060164]])
measurements['J1537'] = {'measured_fluxes': np.array([1.0, 0.726, 0.955, 0.731]),
                          'flux_ratio_covariance_matrix': cov_mat_1537,
                         'keep_flux_ratio_index': [0,1,2],
                         'uncertainty_on_ratios': True}

cov_mat_2145 = np.array([[0.0003344613061172894, -7.727154907068195e-06, 1.1671423564129255e-05],
                                                              [-7.727154907068195e-06, 7.743875252562748e-06, -7.194873914620518e-07],
                                                              [1.1671423564129255e-05, -7.194873914620518e-07, 2.5084781505338595e-05]])
measurements['J2145'] = {'measured_fluxes': np.array([1.0, 0.760, 0.139, 0.248]),
                               'flux_ratio_covariance_matrix': cov_mat_2145,
                               'keep_flux_ratio_index': [0,1,2],
                         'uncertainty_on_ratios': True}

cov_mat_2205 = np.array([[0.00018686301108181708, 1.2031476778001901e-05, 9.914258951674069e-06],
                                                              [1.2031476778001901e-05, 0.0007890712327085082, 3.85702892777173e-05],
                                                             [9.914258951674069e-06, 3.85702892777173e-05, 0.00024158730706583438]])
measurements['J2205'] = {'measured_fluxes': np.array([1.0, 1.551, 2.704, 1.671]) ,
                               'flux_ratio_covariance_matrix': cov_mat_2205,
                               'keep_flux_ratio_index': [0,1,2],
                         'uncertainty_on_ratios': True}


cov_mat_2344 = np.array([[0.0007864762109746211, -1.5547395483753762e-06, 3.10801263308553e-05],
                                                              [-1.5547395483753762e-06, 0.00047235580863676057, 4.0075954697176876e-05],
                                                              [3.10801263308553e-05, 4.0075954697176876e-05, 0.001130937543493442]])
measurements['J2344'] = {'measured_fluxes': np.array([1.0, 1.170, 0.896, 1.491]),
                               'flux_ratio_covariance_matrix': cov_mat_2344,
                               'keep_flux_ratio_index': [0,1,2],
                         'uncertainty_on_ratios': True}

cov_mat_1134 = np.array([[5.501207789187065e-05, 1.7263829139136934e-05, 5.92748846458949e-06],
                                                                  [1.7263829139136934e-05, 0.0009959733266721037, 5.834320100895496e-06],
                                                                  [5.92748846458949e-06, 5.834320100895496e-06, 0.0003094148647027755]])
measurements['M1134'] = {'measured_fluxes': np.array([1.0, 0.244, 1.052, 0.543]) ,
                               'flux_ratio_covariance_matrix': cov_mat_1134,
                               'keep_flux_ratio_index': [0,1,2],
                         'uncertainty_on_ratios': True}


cov_mat_0414 = np.array([[0.0011423153373291434, -3.657003254034274e-05, 1.950383379166294e-05],
                                                                   [-3.657003254034274e-05, 0.00015497357910887555, -2.9553793802656633e-06],
                                                                   [1.950383379166294e-05, -2.9553793802656633e-06, 2.206707720956966e-05]])
measurements['MG0414'] = {'measured_fluxes': np.array([1.0, 0.894, 0.367, 0.143]) ,
                               'flux_ratio_covariance_matrix': cov_mat_0414,
                               'keep_flux_ratio_index': [0,1,2],
                          'uncertainty_on_ratios': True}

cov_mat_1115 = np.array([[0.0007162068077840471, -6.077881568536097e-06, -5.943611370886766e-05],
                                                               [-6.077881568536097e-06, 0.011144567573858828, 0.002960486362778016],
                                                               [-5.943611370886766e-05, 0.002960486362778016, 0.02157860824771848]])
measurements['PG1115'] = {'measured_fluxes': np.array([1.0, 1.338, 4.759, 5.353]) ,
                               'flux_ratio_covariance_matrix': cov_mat_1115,
                               'keep_flux_ratio_index': [0,1,2],
                          'uncertainty_on_ratios': True}

cov_mat_0147 = np.array([[0.00021742987911633208, 1.707449449146671e-05, 3.670884085145561e-06],
                                                                [1.707449449146671e-05, 5.706123522911138e-05, 8.157127649062047e-07],
                                                                [3.670884085145561e-06, 8.157127649062047e-07, 1.8595676424185189e-06]])
measurements['PSJ0147'] = {'measured_fluxes': np.array([1.0, 0.630, 0.365, 0.061]),
                               'flux_ratio_covariance_matrix': cov_mat_0147,
                               'keep_flux_ratio_index': [0,1,2],
                           'uncertainty_on_ratios': True}

cov_mat_1606 = np.array([[0.0009365915498793923, -1.2390272993742104e-05, 1.1280252890365762e-05],
                                                                [-1.2390272993742104e-05, 0.00034923937921132374, -4.110265310784394e-06],
                                                                [1.1280252890365762e-05, -4.110265310784394e-06, 0.0005004580106355308]])
measurements['PSJ1606'] = {'measured_fluxes': np.array([1.0, 1.006, 0.585, 0.746]),
                               'flux_ratio_covariance_matrix': cov_mat_1606,
                               'keep_flux_ratio_index': [0,1,2],
                           'uncertainty_on_ratios': True}


cov_mat_0911 = np.array([[0.02518675, 0.00904832, 0.00408518],
       [0.00904832, 0.01000332, 0.00218503],
       [0.00408518, 0.00218503, 0.006169  ]])
measurements['RXJ0911'] = {'measured_fluxes': np.array([0.56, 1.0, 0.53, 0.24]),
				'flux_ratio_covariance_matrix': cov_mat_0911,
                               'keep_flux_ratio_index': [0,1,2],
                           'uncertainty_on_ratios': True}

cov_mat_rxj1131 = np.array([[0.000732743973116785, 1.8215833377352696e-05, 2.6413513410551247e-07],
                                                                    [1.8215833377352696e-05, 0.00033935315438929554, 1.6954830778282591e-06],
                                                                    [2.6413513410551247e-07, 1.6954830778282591e-06, 7.85275111166195e-06]])
measurements['RXJ1131'] = {'measured_fluxes': np.array([1.0, 0.553, 0.410, 0.053]) ,
                               'flux_ratio_covariance_matrix': cov_mat_rxj1131,
                               'keep_flux_ratio_index': [0,1,2],
                           'uncertainty_on_ratios': True}


cov_mat_2026 = np.array([[0.00027994145334003074, -2.8955472393629443e-06, 6.785449613138441e-07],
                                                                [-2.8955472393629443e-06, 4.6329102077546444e-05, -4.734420552170573e-07],
                                                                [6.785449613138441e-07, -4.734420552170573e-07, 3.160396278103119e-05]])
measurements['WFI2026'] = {'measured_fluxes': np.array([1.0, 0.775, 0.304, 0.281]) ,
                               'flux_ratio_covariance_matrix': cov_mat_2026,
                               'keep_flux_ratio_index': [0,1,2],
                           'uncertainty_on_ratios': True}


cov_mat_2033 = np.array([[0.0002766400711612549, 1.81712827642261e-05, 6.674568457916562e-06], 
	[1.81712827642261e-05, 0.00012288873072475377, 8.51587135465206e-06], 
	[6.674568457916562e-06, 8.51587135465206e-06, 0.00014651184172731892]])
measurements['WFI2033'] = {'measured_fluxes': np.array([1.0, 0.722, 0.526, 0.605]) ,
                               'flux_ratio_covariance_matrix': cov_mat_2033,
                               'keep_flux_ratio_index': [0,1,2],
                           'uncertainty_on_ratios': True}

cov_mat_2038 = np.array([[0.0013163769158846795, 0.00012240530553126578, 9.1145427724005e-05],
                                                                [0.00012240530553126578, 0.0008747728497371431, 5.562121299135247e-05],
                                                                [9.1145427724005e-05, 5.562121299135247e-05, 0.00020187066122068058]])
measurements['WGD2038'] = {'measured_fluxes': np.array([1.0, 1.209, 0.939, 0.430]),
                               'flux_ratio_covariance_matrix': cov_mat_2038,
                               'keep_flux_ratio_index': [0,1,2],
                           'uncertainty_on_ratios': True}
