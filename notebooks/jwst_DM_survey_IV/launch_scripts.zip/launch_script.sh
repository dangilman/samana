#!/bin/bash -l
#module load python/3.9.6 #replace with whatever python version runs best on your cluster

# format for the arguments is:
# - argument 1: job index, or SGE_TASK_ID for SLURM
# - argument 2: number of realizations per CPU
# - argument 3: tolerance on the flux-ratio likelihood that triggers the modeling of imaging data
# for systems without imaging data (B1422, RXJ0911, and WFI2026) we omit the last arg

# for testing
python3 wdm_inference_arcs_new/testing_script.py $1 4 100000

# run by Daniel
#python3 wdm_inference_arcs_new/b1422.py $1 100
#python3 wdm_inference_arcs_new/wfi2026.py $1 100
#python3 wdm_inference_arcs_new/rxj0911.py $1 100
python3 wdm_inference_arcs_new/j0248.py $1 50 -1
python3 wdm_inference_arcs_new/j0607.py $1 50 -1
python3 wdm_inference_arcs_new/j0608.py $1 50 -1
python3 wdm_inference_arcs_new/psj0147.py $1 50 -1
python3 wdm_inference_arcs_new/j2344.py $1 50 -1
python3 wdm_inference_arcs_new/j2145.py $1 50 -1
python3 wdm_inference_arcs_new/j1042.py $1 50 -1
python3 wdm_inference_arcs_new/rxj1131.py $1 50 -1

# run by Anna
python3 wdm_inference_arcs_new/j0924.py $1 50 -1
python3 wdm_inference_arcs_new/j1131.py $1 50 -1
python3 wdm_inference_arcs_new/j1251.py $1 50 -1
python3 wdm_inference_arcs_new/m1134.py $1 50 -1
python3 wdm_inference_arcs_new/j0259.py $1 50 -1
python3 wdm_inference_arcs_new/j0405.py $1 50 -1
python3 wdm_inference_arcs_new/wgd2038.py $1 50 -1
python3 wdm_inference_arcs_new/h1413.py $1 50 -1
python3 wdm_inference_arcs_new/j0659.py $1 50 -1

# run by Andrew
python3 wdm_inference_arcs_new/he0435.py $1 50 -1
python3 wdm_inference_arcs_new/j0803.py $1 50 -1
python3 wdm_inference_arcs_new/j1537.py $1 50 -1
python3 wdm_inference_arcs_new/j2205.py $1 50 -1
python3 wdm_inference_arcs_new/mg0414.py $1 50 -1
python3 wdm_inference_arcs_new/pg1115.py $1 50 -1
python3 wdm_inference_arcs_new/psj1606.py $1 50 -1
python3 wdm_inference_arcs_new/wfi2033.py $1 50 -1
