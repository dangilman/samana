preset_model_name = 'WDM'
kwargs_globular_cluster = {'log10_mgc_mean': 5.3,
                                    'log10_mgc_sigma': 0.6,
                                    'rendering_radius_arcsec': 0.2,
                                'gc_surface_mass_density': 10 ** 5.6,
                           'gc_density_profile': 'PTMASS'
                   }
kwargs_sample_realization = {'log10_sigma_sub': ['UNIFORM', -2.2, 0.2],
                                     'log_mc': ['UNIFORM', 4.0, 10.0],
                                     'log_mlow': ['FIXED', 6.0],
                                     'log_mhigh': ['FIXED', 10.7],
                                     'LOS_normalization': ['UNIFORM', 0.9, 1.1],
                                     'shmf_log_slope': ['UNIFORM', -1.95, -1.85],
                                     'log_m_host': ['GAUSSIAN', 13.3, 0.3],
                                     'truncation_model_subhalos': ['FIXED', 'TRUNCATION_GALACTICUS'],
                                     'add_globular_clusters': ['FIXED', True],
                                    'subhalo_spatial_distribution': ['FIXED', 'UNIFORM']
                                     }
filter_subhalo_kwargs = {'aperture_radius_arcsec': 0.25,
                             'log10_mass_minimum': 7.0}
kappa_scale_subhalos = 0.05
log10_bound_mass_cut = 4.0

